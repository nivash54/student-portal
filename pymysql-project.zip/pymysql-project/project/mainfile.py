from tabulate import tabulate
from pymysql import*

con=connect(host="localhost",user="root",password="",database="studentsportal")

def student():
    std_name=input("enter the student name:")
    try:
        con=connect(host="localhost",user="root",password="",database="studentsportal")
        q="select*from studentinformation where std_name='{0}'".format(std_name)
        c=con.cursor()
        c.execute(q)
        r=c.fetchall()
        con.close()
        c=0
        for i in r:
                print(tabulate(r,headers=["std_name","age","phone","gender","degree","passedOutyear","percentage","course","place"]))
                c=1
        if(c==0):
            print("no such student in that name")
    except Exception as e:
        print(e)
        
def placement():
    degree=input("enter the degree of the student:")
    q="select*from placementinformation where degree='{0}'".format(degree)
    c=con.cursor()
    c.execute(q)
    r=c.fetchall()
    print(tabulate(r,headers=["client","interview_dt","tech","salary","eligible","std_name","phone","degree","passedout","place"]))

print("                            ")
print("STUDENTS AND PLACEMENT INFO:")
ch=int(input("\n 1.studentinfo \n 2.placementinfo \n select any 1:"))
if(ch==1):
    student()
elif(ch==2):
    placement()
else:
    print("invalid.....")
