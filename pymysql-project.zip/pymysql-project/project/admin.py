from tabulate import tabulate
from pymysql import *
c=0
def admin():
    global c
    admin_name=input("Enter the user name :")
    password=input("Enter the Password :")
    try:
        con=connect(host="localhost",user="root",password="",database="studentsportal")
        print("database connected.....")
        q="select * from admin where admin_name='{0}' and password='{1}'".format(admin_name,password)
        c=con.cursor()
        c.execute(q)
        re=c.fetchall()
        con.close()
        for i in re:
            c=1
    except Exception as e:
        print(e)
admin()
if(c==1):
    s=int(input("1.Student info \n2.Placememt info \nSelect any 1: "))
    if(s==1):
        from portal.studentinf import*  
    elif(s==2):
       from portal.placementinf import*
    else:
        print("invalid choice...")
else:
    print("Invalid user name... or Invalid Password...")