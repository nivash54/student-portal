#pip install tabulate
from tabulate import tabulate
from pymysql import*

con=connect(host="localhost",user="root",password="",database="studentsportal")

def insert(client,interview_dt,tech,salary,eligible,std_name,phone,degree,passedout,place):
    q="insert into placementinformation values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')".format(client,interview_dt,tech,salary,eligible,std_name,phone,degree,passedout,place)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data saved successfully....")
    
def update(degree,std_name):
    q="update placementinformation set degree='{0}' where std_name='{1}'".format(degree,std_name)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data updated successfully...")
    
def select():
    q="select * from placementinformation"
    c=con.cursor()
    c.execute(q)
    r=c.fetchall()
    print(tabulate(r,headers=["client","interview_dt","tech","salary","eligible","std_name","phone","degree","passedout","place"]))

def delete(tech):
    q="delete from placementinformation where tech='{0}'".format(tech)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data deleted successfully..")

ch=int(input(" 1.insert \n 2.update \n 3.select \n 4.delete \nSelect any one :"))
if(ch==1):
    client=input("enter the client name:")
    interview_dt=input("enter the interview date:")
    tech=input("enter the course complted:")
    salary=int(input("enter the offering salary:"))
    eligible=input("enter the eligibility for interview:")
    std_name=input("enter your name:")
    phone=int(input("enter your contact number:"))
    degree=input("enter your qualification:")
    passedout=int(input("enter your passed out year:"))
    place=input("enter your location:")
    insert(client,interview_dt,tech,salary,eligible,std_name,phone,degree,passedout,place)
elif(ch==2):
    degree=input("enter the qualification name to update:")
    std_name=input("enter your name:")
    update(degree,std_name)
elif(ch==3):
    select()
elif(ch==4):
    tech=input("enter the name of technology to delete:")
    delete(tech)
else:
    print("invalid choice......")




















