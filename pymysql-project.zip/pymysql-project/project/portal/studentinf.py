from tabulate import tabulate
from pymysql import*

con=connect(host="localhost",user="root",password="",database="studentsportal")

def insert(std_name,age,phone,gender,degree,passedOutyear,percentage,course,place):
    q="insert into studentinformation values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')".format(std_name,age,phone,gender,degree,passedOutyear,percentage,course,place)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data is Saved.....")
    
def update(course,std_name):
    q="update studentinformation set course='{0}' where std_name='{1}'".format(course,std_name)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data is updated successfully...")
    
def select():
    q="select * from studentinformation"
    c=con.cursor()
    c.execute(q)
    r=c.fetchall()
    print(tabulate(r,headers=["std_name","age","phone","gender","degree","passedOutyear","percentage","course","place"]))
    
def delete(std_name):
    q="delete from studentinformation where std_name='{0}'".format(std_name)
    c=con.cursor()
    c.execute(q)
    con.commit()
    con.close()
    print("Data is deleted successfully..")
    
ch=int(input(" 1.insert \n 2.update \n 3.select \n 4.delete \nSelect any one :"))
if(ch==1):
    std_name=input("enter the student name:")
    age=int(input("enter your age:"))
    phone=int(input("enter your contact number:"))
    gender=input("enter your gender:")
    degree=input("enter your qualification:")
    passedOutyear=int(input("enter your year of passedout:"))
    percentage=int(input("enter your percentage:"))
    course=input("enter your course completed:")
    place=input("enter your location:")
    insert(std_name,age,phone,gender,degree,passedOutyear,percentage,course,place)
elif(ch==2):
    course=input("enter the course name to update:")
    std_name=input("enter your name:")
    update(course,std_name)
elif(ch==3):
    select()
elif(ch==4):
    std_name=input("enter the student name to delete:")
    delete(std_name)
else:
    print("invalid choice......")